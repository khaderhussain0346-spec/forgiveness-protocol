# THE FORGIVENESS PROTOCOL ❤️

A playful, interactive apology mini-game built with vanilla HTML, CSS and JavaScript. One certified idiot is under investigation; one very special human is the judge.

## Features
- Secret-access welcome screen
- Funny case report / investigation file
- Six interactive questions with custom reactions
- Animated apology terminal
- Typing-effect heartfelt message
- Forgiveness challenge with three respectful responses
- Floating hearts, subtle motion and responsive layouts
- No backend, framework, paid API or build step

## Run locally
1. Download and unzip the project.
2. Open `index.html` in a browser.
3. That's it — no installation required.

## Personalize before sharing
Open `index.html` and edit the heartfelt paragraph in the `heartfeltText` string inside `script.js`. Make sure it matches what actually happened. The default message is intentionally gentle and does not demand forgiveness.

You can also edit the final signature in `index.html` (`Your favourite idiot.`).

## Publish with GitHub Pages
1. Sign in to GitHub and create a **New repository** named `the-forgiveness-protocol`.
2. Choose **Public** (or your preferred visibility setting) and create the repository.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` from this folder to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a minute or two. GitHub will show the published website URL in the Pages section.
8. Open the URL on your phone to test it, then share it with your friend.

## Project structure
```text
the-forgiveness-protocol/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Notes
- Google Fonts are used when internet access is available; system sans-serif fallbacks are included.
- All interactions run in the browser.
- The final screen appears regardless of the selected response. The "Not yet" choice is treated respectfully; it is not a request to forgive immediately.
