const screens = [...document.querySelectorAll(".screen")];
const byId = id => document.getElementById(id);
function showScreen(id) {
  screens.forEach(s => s.classList.toggle("active", s.id === id));
  window.scrollTo({top:0,behavior:"smooth"});
}
function toast(message) {
  const el=byId("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2600);
}
byId("accessBtn").addEventListener("click",()=>showScreen("investigationScreen"));
document.querySelectorAll("[data-next]").forEach(btn=>btn.addEventListener("click",()=>showScreen(btn.dataset.next)));

const questions = [
 {icon:"🧠",q:"On a scale of 1 to 10, how stupid is this person?",a:["A solid 11/10","Needs a calculator","Scientifically unmeasurable","I plead the fifth"],r:["Ouch. The suspect accepts this rating.","The calculator has resigned.","Researchers are still confused.","A suspicious silence. Noted."]},
 {icon:"🛠️",q:"Should this idiot be forgiven or sent for software updates?",a:["Forgive the buggy human","Install 47 updates","Factory reset needed","Depends on the apology"],r:["A generous ruling. The suspect is grateful.","Updates downloading… slowly.","Please keep personal files safe.","Fair. The apology must do the talking."]},
 {icon:"😅",q:"Is this person your favourite headache?",a:["Unfortunately, yes","On alternate Tuesdays","Headache is an understatement","No comments, officer"],r:["A prestigious title, apparently.","The schedule has been updated.","Medical assistance for the suspect?","The officer respects your privacy."]},
 {icon:"⚖️",q:"What punishment should be given?",a:["One sincere apology","A lifetime of better behaviour","Make them bring snacks","All of the above"],r:["The court approves sincerity.","A fair and reasonable sentence.","Snack negotiations may begin.","A tough but adorable verdict."]},
 {icon:"🌱",q:"Does this person deserve another chance?",a:["Everyone can learn","Show me the improvement","Maybe, with time","I'm still deciding"],r:["The suspect promises to keep learning.","Actions > words. Completely fair.","Take all the time you need.","No rush. Your choice matters."]},
 {icon:"🎭",q:"Who is more dramatic, you or me?",a:["Obviously you","Obviously me","A shared achievement","The entire friend group"],r:["The suspect requests a recount.","Self-awareness detected. Rare event.","A balanced ecosystem of drama.","Case expanded to the whole group."]}
];
let qIndex=0;
function renderQuestion(){
 const q=questions[qIndex]; byId("questionIcon").textContent=q.icon; byId("questionText").textContent=q.q;
 byId("quizCount").textContent=`QUESTION ${String(qIndex+1).padStart(2,"0")} / 06`;
 byId("quizProgress").style.width=`${((qIndex+1)/questions.length)*100}%`;
 byId("reaction").textContent="Choose wisely, Your Honour.";
 const list=byId("answerList"); list.innerHTML="";
 q.a.forEach((answer,i)=>{const b=document.createElement("button");b.className="answer-btn";b.textContent=answer;b.addEventListener("click",()=>{
   [...list.children].forEach(x=>x.disabled=true); byId("reaction").textContent=q.r[i];
   setTimeout(()=>{if(qIndex<questions.length-1){qIndex++;renderQuestion();}else{startTerminal();}},1050);
 });list.appendChild(b);});
}
byId("skipQuiz").addEventListener("click",startTerminal);
function startTerminal(){showScreen("terminalScreen");byId("terminalLines").innerHTML="";byId("terminalContinue").classList.add("hidden");byId("terminalState").textContent="RUNNING";
 const lines=[
  ["Initializing apology.exe...", ""],
  ["Checking sincerity...", ""],
  ["Scanning stupidity...", ""],
  ["Detecting genuine feelings...", ""],
  ["Result: This idiot is genuinely sorry. ❤️","done"]
 ];
 lines.forEach((line,i)=>setTimeout(()=>{const p=document.createElement("p");p.textContent="> "+line[0];if(line[1])p.classList.add(line[1]);byId("terminalLines").appendChild(p);
   if(i===lines.length-1){byId("terminalState").textContent="COMPLETE";byId("terminalCursor").classList.add("hidden");byId("terminalContinue").classList.remove("hidden");}
 },650+i*1050));
}
byId("terminalContinue").addEventListener("click",()=>{showScreen("messageScreen");typeMessage();});
const heartfelt="Jokes apart, I genuinely want to say sorry. I know I made a mistake, and I don't want to make excuses for it. You are someone I genuinely value, and I never wanted my actions to make you feel bad. I might be an idiot sometimes, but my appreciation for you is real. I'm truly sorry.";
let typingTimer;
function typeMessage(){clearInterval(typingTimer);byId("heartfeltText").textContent="";byId("messageContinue").classList.add("hidden");byId("messageCursor").classList.remove("hidden");let i=0;
 typingTimer=setInterval(()=>{byId("heartfeltText").textContent+=heartfelt[i++];if(i>=heartfelt.length){clearInterval(typingTimer);byId("messageCursor").classList.add("hidden");byId("messageContinue").classList.remove("hidden");}},24);
}
byId("messageContinue").addEventListener("click",()=>showScreen("forgiveScreen"));
document.querySelectorAll("[data-choice]").forEach(btn=>btn.addEventListener("click",()=>{
 const response=byId("choiceResponse");
 const messages={
  yes:"A little hope unlocked. ❤️ Thank you. The suspect will keep proving it through actions.",
  later:"That's completely okay. No timer, no pressure. Take the time you need. 💗",
  snacks:"A highly reasonable request. 🍫 Snack negotiations noted — but the apology is still sincere."
 };
 response.textContent=messages[btn.dataset.choice];
 if(btn.dataset.choice==="yes") heartsBurst();
 if(btn.dataset.choice==="later") toast("No pressure. Your feelings come first. 💗");
 if(btn.dataset.choice==="snacks") toast("Chocolate clause added to the case file 🍫");
 setTimeout(()=>showScreen("finalScreen"),2600);
}));
function heartsBurst(){for(let i=0;i<22;i++){const h=document.createElement("span");h.className="floaty";h.textContent=["♥","♡","✦","✧"][i%4];h.style.left=Math.random()*100+"%";h.style.fontSize=(12+Math.random()*18)+"px";h.style.animationDuration=(3+Math.random()*2)+"s";byId("floatLayer").appendChild(h);setTimeout(()=>h.remove(),5500);}}
setInterval(()=>{if(Math.random()<.65){const h=document.createElement("span");h.className="floaty";h.textContent=["♡","✦","♥"][Math.floor(Math.random()*3)];h.style.left=Math.random()*100+"%";h.style.fontSize=(10+Math.random()*13)+"px";h.style.animationDuration=(8+Math.random()*5)+"s";byId("floatLayer").appendChild(h);setTimeout(()=>h.remove(),14000);}},1400);
byId("restartBtn").addEventListener("click",()=>{qIndex=0;clearInterval(typingTimer);byId("terminalCursor").classList.remove("hidden");byId("terminalState").textContent="STANDBY";byId("choiceResponse").textContent="";renderQuestion();showScreen("accessScreen");});
renderQuestion();
